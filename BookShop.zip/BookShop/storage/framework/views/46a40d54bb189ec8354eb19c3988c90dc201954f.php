

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>E-SHOP</title>

    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" />

    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('frontend/css/slick.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('frontend/css/slick-theme.css')); ?>" />

    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('frontend/css/nouislider.min.css')); ?>" />

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>">

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>" />

    



</head>

<body>
    <!-- HEADER -->
    <header>
        <!-- top Header -->
        <div id="top-header">
            <div class="container">
                <div class="pull-left">
                    <span>Welcome to E-shop!</span>
                </div>
                <div class="pull-right">
                    <ul class="header-top-links">
                        <li><a href="#">Store</a></li>
                        <li><a href="#">Newsletter</a></li>
                        <li><a href="#">FAQ</a></li>
                        <li class="dropdown default-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">ENG <i class="fa fa-caret-down"></i></a>
                            <ul class="custom-menu">
                                <li><a href="#">English (ENG)</a></li>
                                <li><a href="#">Bangla (BAN)</a></li>
                                
                            </ul>
                        </li>
                        <li class="dropdown default-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">USD <i class="fa fa-caret-down"></i></a>
                            <ul class="custom-menu">
                                <li><a href="#">USD ($)</a></li>
                                <li><a href="#">BD (৳2)</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /top Header -->

        <!-- header -->
        <div id="header">
            <div class="container">
                <div class="pull-left">
                    <!-- Logo -->
                    <div class="header-logo">
                        <a class="logo" href="#">
                            <img src="./img/logo.png" alt="">
                        </a>
                    </div>
                    <!-- /Logo -->

                    <!-- Search -->
                    <div class="header-search">
                        <form>
                            <input class="input search-input" type="text" placeholder="Enter your book Title...">
                            <select class="input search-categories">
                                <option value="0">All Categories</option>
                                <option value="1">স্কুল, কলেজ, মাদ্রাসা ও কারিগরি শিক্ষা</option>
                                <option value="2">UNIVERSITY</option>
                                <option value="3">মেডিকেল, ডেন্টাল, নার্সিং অন্যান্য</option>
                                <option value="4">ভর্তি, নিয়োগ ও প্রস্তুতি পরীক্ষা</option>
                                <option value="5">গল্প, উপন্যাস ও অন্যান্য</option>
                                <option value="6">VIEW ALL</option>
                            </select>
                            <button class="search-btn"><i class="fa fa-search"></i></button>
                        </form>
                    </div>
                    <!-- /Search -->
                </div>
                <div class="pull-right">
                    <ul class="header-btns">
                        <!-- Account -->
                        <li class="header-account dropdown default-dropdown">
                            <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-user-o"></i>
                                </div>
                                <strong class="text-uppercase">My Account <i class="fa fa-caret-down"></i></strong>
                            </div>
                            <a href="#" class="text-uppercase">Login</a> / <a href="#" class="text-uppercase">Join</a>
                            <ul class="custom-menu">
                                <li><a href="#"><i class="fa fa-user-o"></i> My Account</a></li>
                                <li><a href="#"><i class="fa fa-heart-o"></i> My Wishlist</a></li>
                                <li><a href="#"><i class="fa fa-exchange"></i> Compare</a></li>
                                <li><a href="#"><i class="fa fa-check"></i> Checkout</a></li>
                                <li><a href="#"><i class="fa fa-unlock-alt"></i> Login</a></li>
                                
                            </ul>
                        </li>
                        <!-- /Account -->

                        <!-- Cart -->
                        <li class="header-cart dropdown default-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <div class="header-btns-icon">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span class="qty">3</span>
                                </div>
                                <strong class="text-uppercase">My Cart:</strong>
                                <br>
                                <span>35.20$</span>
                            </a>
                            <div class="custom-menu">
                                <div id="shopping-cart">
                                    <div class="shopping-cart-list">
                                        <div class="product product-widget">
                                            <div class="product-thumb">
                                                <img src="./img/thumb-product01.jpg" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
                                                <h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
                                            </div>
                                            <button class="cancel-btn"><i class="fa fa-trash"></i></button>
                                        </div>
                                        <div class="product product-widget">
                                            <div class="product-thumb">
                                                <img src="./img/thumb-product01.jpg" alt="">
                                            </div>
                                            <div class="product-body">
                                                <h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
                                                <h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
                                            </div>
                                            <button class="cancel-btn"><i class="fa fa-trash"></i></button>
                                        </div>
                                    </div>
                                    <div class="shopping-cart-btns">
                                        <button class="main-btn">View Cart</button>
                                        <button class="primary-btn">Checkout <i class="fa fa-arrow-circle-right"></i></button>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <!-- /Cart -->

                        <!-- Mobile nav toggle-->
                        <li class="nav-toggle">
                            <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
                        </li>
                        <!-- / Mobile nav toggle -->
                    </ul>
                </div>
            </div>
            <!-- header -->
        </div>
        <!-- container -->
    </header>
    <!-- /HEADER -->

    <!-- NAVIGATION -->
    <div id="navigation">
        <!-- container -->
        <div class="container">
            <div id="responsive-nav">
                <!-- category nav -->
                <div class="category-nav">
                    <span class="category-header">Books Categories <i class="fa fa-list"></i></span>
                    <ul class="category-list">
                        <li class="dropdown side-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">স্কুল, কলেজ, মাদ্রাসা ও কারিগরি শিক্ষা <i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">ইংলিশ মিডিয়াম </h3></li>
                                            <li><a href="#">ইংলিশ মিডিয়াম: কেজি</a></li>
                                            <li><a href="#">ইংলিশ মিডিয়াম: A লেভেল</a></li>
                                            <li><a href="#">ইংলিশ মিডিয়াম: O লেভেল</a></li>
                                            <li><a href="#">ইংলিশ মিডিয়াম: ক্লাস ফাইভ</a></li>
                                            <li><a href="#">ইংলিশ মিডিয়াম: ক্লাস ফোর</a></li>
                                            <li><a href="#">ইংলিশ মিডিয়াম: ক্লাস সিক্স</a></li>
                                            
                                        </ul>
                                        <hr>
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">স্কুল</h3></li>
                                            <li><a href="#">নবম ও দশম: বিজ্ঞান</a></li>
                                            <li><a href="#">নবম ও দশম: ব্যবসায়</a></li>
                                            <li><a href="#">নবম ও দশম: মানবিক</a></li>
                                            <li><a href="#">অষ্টম শ্রেণি</a></li>
                                            <li><a href="#">পিএসসি</a></li>
                                            <li><a href="#">সপ্তম শ্রেণি</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">মাদ্রাসা</h3></li>
                                            <li><a href="#">আলিম</a></li>
                                            <li><a href="#">কামিল</a></li>
                                            <li><a href="#">দাখিল</a></li>
                                            <li><a href="#">ফাযিল</a></li>
                                            <li><a href="#">দাখিল</a></li>
                                            <li><a href="#">ফাযিল</a></li>
                                            

                                        </ul>
                                        <hr>
                                    </div>

                                    

                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">কারিগরি শিক্ষা</h3></li>
                                            <li><a href="#">অটোমোবাইল ইঞ্জিনিয়ারিং</a></li>
                                            <li><a href="#">আর্কিটেকচার</a></li>
                                            <li><a href="#">ইলেকট্রিক্যাল এন্ড ইলেকট্রনিক্স ইঞ্জিনিয়ারিং</a></li>
                                            <li><a href="#">এনভায়রমেন্টাল ইঞ্জিনিয়ারিং</a></li>
                                            <li><a href="#">কম্পিউটার সায়েন্স অ্যান্ড টেকনোলজি</a></li>
                                            <li><a href="#">সিভিল ইঞ্জিনিয়ারিং</a></li>
                                            <li><a href="#">ডাটা টেলিকমিউনিকেশন অ্যান্ড নেটওয়ার্কিং</a></li>
                                            <li><a href="#">টেলিকমিউনিকেশন ইঞ্জিনিয়ারিং</a></li>
                                            <li><a href="#">মেকানিক্যাল ইঞ্জিনিয়ারিং</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                        
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">কলেজ (এইচএসসি)</h3></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক বাংলা</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক ইংরেজি</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক গণিত</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক পদার্থবিজ্ঞান</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক জীববিজ্ঞান</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক রসায়ন</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক তথ্য ও যোগাযোগ প্রযুক্তি</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক মনোবিজ্ঞান</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক পৌরনীতি</a></li>
                                            <li><a href="#">উচ্চ মাধ্যমিক হিসাববিজ্ঞান</a></li>
                                        </ul>
                                        <hr>
                                    </div>
                                </div>
                                
                        
                        <li class="dropdown side-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">University<i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Public & Private University</h3></li>
                                            <li><a href="#">অনুজীব বিজ্ঞান</a></li>
                                            <li><a href="#">আইন</a></li>
                                            <li><a href="#">উদ্ভিদ বিজ্ঞান </a></li>
                                            <li><a href="#">সমাজ বিজ্ঞান</a></li>
                                            <li><a href="#">ইতিহাস</a></li>
                                            <li><a href="#">ইসলাম শিক্ষা</a></li>
                                            <li><a href="#">ইসলামের ইতিহাস ও সংস্কৃতি</a></li>
                                            <li><a href="#">দর্শন </a></li>
                                            <li><a href="#">উন্নয়ন বিদ্যা</a></li>
                                            <li><a href="#">গণিত</a></li>
                                            <li><a href="#">মনোবিজ্ঞান</a></li>
                                            <li><a href="#">রাষ্ট্রবিজ্ঞান</a></li>
                                            <li><a href="#">পদার্থ বিজ্ঞান ও ফলিত পদার্থ বিদ্যা</a></li>
                                            <li><a href="#">পরিসংখ্যান</a></li>
                                            <li><a href="#">রসায়ন ও ফলিত রসায়ন</a></li>
                                            

                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">National University</h3></li>
                                            <li><a href="#">বাংলা </a></li>
                                            <li><a href="#">ইংরেজি</a></li>
                                            <li><a href="#">অর্থনীতি </a></li>
                                            <li><a href="#">সমাজ বিজ্ঞান</a></li>
                                            <li><a href="#">ইতিহাস</a></li>
                                            <li><a href="#">ইসলাম শিক্ষা</a></li>
                                            <li><a href="#">ইসলামের ইতিহাস ও সংস্কৃতি</a></li>
                                            <li><a href="#">দর্শন </a></li>
                                            <li><a href="#">ফিন্যান্স</a></li>
                                            <li><a href="#">ব্যবস্থাপনা</a></li>
                                            <li><a href="#">মনোবিজ্ঞান</a></li>
                                            <li><a href="#">রাষ্ট্রবিজ্ঞান</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-6">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Engeneering</h3></li>
                                            <li><a href="#">Computer Science & Engineering</a></li>
                                            <li><a href="#">Electrical & Electronic Engineering</a></li>
                                            <li><a href="#">Civil Engineering</a></li>
                                            <li><a href="#">Mechanical Engineering</a></li>
                                            <li><a href="#">Architecture</a></li>
                                            <li><a href="#">Naval Architecture & Marine Engineering</a></li>
                                            <li><a href="#">Industrial & Production Engineering</a></li>
                                            <li><a href="#">Water Resources Engineering</a></li>
                                            <li><a href="#">Chemical Engineering</a></li>
                                            <li><a href="#">Nuclear Engineering</a></li>
                                            <li><a href="#">Environmental Engineering</a></li>
                                            <li><a href="#">Textile Engineering</a></li>
                                            <li><a href="#">Glass and Ceramics Engineering</a></li>
                                            <li><a href="#">Telecommunication & Network</a></li>
                                            <li><a href="#">Others engineering book</a></li>

                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">BBA / MBA / ACCA</h3></li>
                                            <li><a href="#">ইন্টারন্যাশনাল বিজনেস</a></li>
                                            <li><a href="#">উদ্যোক্তা ও নেতৃত্ব</a></li>
                                            <li><a href="#">একাউন্টিং</a></li>
                                            <li><a href="#">পরিসংখ্যান</a></li>
                                            <li><a href="#">ফিনান্স</a></li>
                                            <li><a href="#">বিজনেস কমিউনিকেশন</a></li>
                                            <li><a href="#">ব্যাংকিং</a></li>
                                            <li><a href="#">মার্কেটিং</a></li>
                                            <li><a href="#">ম্যানেজমেন্ট</a></li>
                                            <li><a href="#">হিউম্যান রিসোর্স ম্যানেজমেন্ট</a></li>
                                        </ul>
                                    </div>
                                

                        <li class="dropdown side-dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">মেডিকেল, ডেন্টাল, নার্সিং অন্যান্য <i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">মেডিকেল</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">ডেন্টাল</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">নার্সিং</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">ভেটেরিনারি ও অ্যানিমেল সায়েন্সেস</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">হসপিটাল ম্যানেজমেন্ট</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">হোমিওপ্যাথিক</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="dropdown side-dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">ভর্তি, নিয়োগ ও প্রস্তুতি পরীক্ষা <i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">বিসিএস</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">IELTS & TOEFL</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">SAT, GRE & GMAT</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">শিক্ষা সহায়ক</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">নিয়োগ প্রস্তুতি</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">ভর্তি পরীক্ষা প্রস্তুতি</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                    

                        <li class="dropdown side-dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">গল্প, উপন্যাস ও অন্যান্য <i class="fa fa-angle-right"></i></a>
                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">Fiction</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">অনুবাদ</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">শিশু কিশোর সাহিত্য</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">সায়েন্সফিকশন</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">মুক্তিযুদ্ধ</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">সাহিত্য সমগ্র</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li><a href="#">View All</a></li>
                    </ul>
                </div>
                <!-- /category nav -->

                <!-- menu nav -->
                <div class="menu-nav">
                    <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
                    <ul class="menu-list">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Shop</a></li>
                        <li class="dropdown mega-dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Writer <i class="fa fa-caret-down"></i></a>

                            <div class="custom-menu">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">বিসিএস</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">IELTS & TOEFL</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">SAT, GRE & GMAT</h3></li>
                                            <li><a href="#">Women’s </a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">শিক্ষা সহায়ক</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr class="hidden-md hidden-lg">
                                    </div>
                                    <div class="col-md-4">
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">নিয়োগ প্রস্তুতি</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                        <hr>
                                        <ul class="list-links">
                                            <li>
                                                <h3 class="list-links-title">ভর্তি পরীক্ষা প্রস্তুতি</h3></li>
                                            <li><a href="#">Women’s Clothing</a></li>
                                            <li><a href="#">Men’s Clothing</a></li>
                                            <li><a href="#">Phones & Accessories</a></li>
                                            <li><a href="#">Jewelry & Watches</a></li>
                                            <li><a href="#">Bags & Shoes</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>

                            
                         
                        <li><a href="#">Sales</a></li>
                    <li class="dropdown default-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Publication <i class="fa fa-caret-down"></i></a>
                            <ul class="custom-menu">
                                <li><a href="index.html">Home</a></li>
                                <li><a href="products.html">Products</a></li>
                                <li><a href="product-page.html">Product Details</a></li>
                                <li><a href="checkout.html">Checkout</a></li>
                            </ul>
                        </li>
                    <li class="dropdown default-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Languages <i class="fa fa-caret-down"></i></a>
                            <ul class="custom-menu">
                                <li><a href="index.html">English</a></li>
                                <li><a href="products.html">Bangla</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- menu nav -->
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /NAVIGATION -->

    <!-- HOME -->
    <div id="home">
        <!-- container -->
        <div class="container">
            <!-- home wrap -->
            <div class="home-wrap">
                <!-- home slick -->
                <div id="home-slick">
                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="<?php echo e(asset('frontend/./img/banner01.jpg')); ?>" alt="">
                        <div class="banner-caption text-center">
                            <h1>Bags sale</h1>
                            <h3 class="white-color font-weak">Up to 50% Discount</h3>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="<?php echo e(asset('frontend./img/banner02.jpg')); ?>" alt="">
                        <div class="banner-caption">
                            <h1 class="primary-color">HOT DEAL<br><span class="white-color font-weak">Up to 50% OFF</span></h1>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="<?php echo e(asset('frontend/./img/banner03.jpg')); ?>" alt="">
                        <div class="banner-caption">
                            <h1 class="white-color">New Product <span>Collection</span></h1>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->
                </div>
                <!-- /home slick -->
            </div>
            <!-- /home wrap -->
        </div>
        <!-- /container -->
    </div>
    <!-- /HOME -->
            
    
    
   <?php echo $__env->yieldContent('content'); ?>

    <!-- FOOTER -->
    <footer id="footer" class="section section-grey">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <!-- footer widget -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <!-- footer logo -->
                        <div class="footer-logo">
                            <a class="logo" href="#">
                    <img src="./img/logo.png" alt="">
                  </a>
                        </div>
                        <!-- /footer logo -->

                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna</p>

                        <!-- footer social -->
                        <ul class="footer-social">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        </ul>
                        <!-- /footer social -->
                    </div>
                </div>
                <!-- /footer widget -->

                <!-- footer widget -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <h3 class="footer-header">My Account</h3>
                        <ul class="list-links">
                            <li><a href="#">My Account</a></li>
                            <li><a href="#">My Wishlist</a></li>
                            <li><a href="#">Compare</a></li>
                            <li><a href="#">Checkout</a></li>
                            <li><a href="#">Login</a></li>
                        </ul>
                    </div>
                </div>
                <!-- /footer widget -->

                <div class="clearfix visible-sm visible-xs"></div>

                <!-- footer widget -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <h3 class="footer-header">Customer Service</h3>
                        <ul class="list-links">
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Shiping & Return</a></li>
                            <li><a href="#">Shiping Guide</a></li>
                            <li><a href="#">FAQ</a></li>
                        </ul>
                    </div>
                </div>
                <!-- /footer widget -->

                <!-- footer subscribe -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="footer">
                        <h3 class="footer-header">Stay Connected</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
                        <form>
                            <div class="form-group">
                                <input class="input" placeholder="Enter Email Address">
                            </div>
                            <button class="primary-btn">Join Newslatter</button>
                        </form>
                    </div>
                </div>
                <!-- /footer subscribe -->
            </div>
            <!-- /row -->
            <hr>
            <!-- row -->
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center">
                    <!-- footer copyright -->
                    <div class="footer-copyright">
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Akter</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                    <!-- /footer copyright -->
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </footer>
    <!-- /FOOTER -->

    <!-- jQuery Plugins -->
    <script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/nouislider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.zoom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>

</body>

</html>

<?php /**PATH C:\xampp\htdocs\Final project\BookShop\resources\views/welcome.blade.php ENDPATH**/ ?>