<?php $__env->startSection('content'); ?>

<!DOCTYPE html>

<html lang="en" class="no-js"> <!--<![endif]-->
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('frontend/css/style.css'); ?>" />

    <link rel="stylesheet" type="text/css" href="<?php echo asset('frontend/css/animate-custom.css'); ?>" />
</head>
<body>
<div class="container">
    <!-- Codrops top bar -->

    <section>
        <div id="container_demo" >
            <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
            <a class="hiddenanchor" id="toregister"></a>
            <a class="hiddenanchor" id="tologin"></a>
            <div id="wrapper">
                <div id="login" class="animate form">
                   
                    <h2> Thanks for orders...</h2>
                     <h2> We will contact as soon as possible</h2>

                </div>


                </div>

            </div>
        </div>
    </section>
</div>

</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/pages/handcash.blade.php ENDPATH**/ ?>