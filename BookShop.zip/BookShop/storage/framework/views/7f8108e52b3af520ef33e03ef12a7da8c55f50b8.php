<?php $__env->startSection('content'); ?>
<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			 <?php if(Session::has('message')): ?>
                <div class="alert alert-success text-center" role="alert">
                    <?php echo e(Session::get('message')); ?>

                </div>
            <?php endif; ?>
			

					<div class="col-md-12">
						<div class="order-summary clearfix">
							<div class="section-title">
								<h3 class="title">Order Review</h3>
							</div>
							<table class="shopping-cart-table table">

							<?php
                             $contents=Cart::content();
							
								?>
								<thead>
									<tr>
										<th>Book</th>
										<th class="text-left">Name</th>
										<th class="text-center">Price</th>
										<th class="text-center">Quantity</th>
										<th class="text-center">Total</th>
										<th class="text-right">Action</th>
									</tr>
								</thead>
								<tbody>
                               <?php  foreach($contents as $v_contents) {?>
									<tr>
										<td class="thumb"><img src="<?php echo e(asset($v_contents->options['image'])); ?>" alt=""></td>
										<td class="details">
											<a href="#"><?php echo e($v_contents->name); ?></a>
											
										</td>
										<td class="price text-center"><strong><?php echo e($v_contents->price); ?></strong><br></td>

										<td class="qty text-center"><input class="input" type="number" value="<?php echo e($v_contents->qty); ?>"></td>
								

										<td class="total text-center"><strong class="primary-color"><?php echo e($v_contents->price*$v_contents->qty); ?></strong></td>
										<td class="text-right">
											<a class="cart_quantity_delete" href="<?php echo e(URL::to('/delete-to-cart/'.$v_contents->rowId)); ?>"><button class="main-btn icon-btn"><i class="fa fa-close"></i></button></a>
										</td>
									</tr>
									<?php }?>

									
								</tbody>
								<tfoot>

									<tr>
										<th class="empty" colspan="3"></th>
										<th>SUBTOTAL</th>
										<th colspan="2" class="sub-total"><?php echo $subtotal; ?></th>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>Tax</th>
										<td colspan="2"><?php echo e(Cart::tax()); ?></td>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>SHIPING</th>
										<td colspan="2">Free Shipping</td>
									</tr>
									<tr>
										<th class="empty" colspan="3"></th>
										<th>TOTAL</th>
										<th colspan="2" class="total"><?php echo $total; ?></th>
									</tr>

								</tfoot>

							</table>
							<div><a href="<?php echo e(URL::to('/home-content')); ?>"><button class="primary-btn"><i class="fa fa-arrow-circle-left">Continue Shopping </i></button></a></div>

							<div class="pull-right">
								<?php $users_id=Session::get('users_id'); ?>

                                <?php if ($users_id != Null) {?>
								<a href="<?php echo e(URL::to('/checkout')); ?>"><button class="primary-btn">Checkout <i class="fa fa-arrow-circle-right"></i></button></a>
								<?php }
                                 else {?>
                                     <a href="<?php echo e(URL::to('/login-check')); ?>"><button class="primary-btn">Checkout <i class="fa fa-arrow-circle-right"></i></button></a>
                                 	<?php } ?>


							</div>
						</div>

					</div>
				</form>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/pages/add_to_cart.blade.php ENDPATH**/ ?>