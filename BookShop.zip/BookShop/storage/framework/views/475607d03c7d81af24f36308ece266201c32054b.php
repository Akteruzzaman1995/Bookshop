<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3 col-sm-6 col-xs-6">
	            <div class="product product-single">
	                <div class="product-thumb">
	                   <li><a href="<?php echo e(URL::to('/view_book/'.$v_book->book_id)); ?>" button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Quick view</button></a></li>
	                    <img src="<?php echo e(URL::to($v_book->book_image)); ?>" alt="">
	                </div>
	                <div class="product-body">
	                    <h3 class="product-price">TK- <?php echo e($v_book->book_price); ?></h3>
	                   
	                   <h2 class="product-name"><a><?php echo e($v_book->book_name); ?></a></h2>
	                    <h2 class="product-name"><a href="#"><?php echo e($v_book->author_name); ?></a></h2>
	                    <div class="product-btns">
	                        <button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
	                        <button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
	                        <a href="<?php echo e(URL::to('/view_book/'.$v_book->book_id)); ?>" button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button></a>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final project\BookShop\resources\views/pages/search_result.blade.php ENDPATH**/ ?>