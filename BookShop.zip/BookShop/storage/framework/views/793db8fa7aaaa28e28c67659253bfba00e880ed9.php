<?php $__env->startSection('content'); ?>


<section id="do_action">
	<div class="container"><br><br>
		
		

                            <ul>
                            	
                           <li><a href="#"><font size="6"><b>Payment Method</b></font></a></li>
                            <font size="4"><span class="payment-header__sub-title">(Please select <em>only one!</em> payment method)</span></font>

                         </ul>


					<form action="<?php echo e(url('/order-place')); ?>" method="post">
			         <?php echo e(csrf_field()); ?>

                    <input type="radio" name="payment_method" value="handcash"> Hand Cash<br>
                    <input type="radio" name="payment_method" value="cart"> Debit Card<br>

                    <input type="radio" name="payment_method" value="paypal"> Paypal<br><br>
                    <a href=""><button class="primary-btn">Confirm payment </button></a>
			</form>
				</div><br><br><br><br>
	</div>

</section><!--/#do_action-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final project\BookShop\resources\views/pages/payment.blade.php ENDPATH**/ ?>