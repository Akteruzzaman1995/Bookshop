<?php $__env->startSection('admin_content'); ?>

<div class="row-fluid sortable">
				<div class="box span6">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>Users Details</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table">
							  <thead>
								  <tr>
									  <td>Usersname</td>
									  <td>Mobile Number</td>
									  <td>Users Email</td>
									                                           
								  </tr>
							  </thead>   
							  <tbody>
								<tr>
									<?php $__currentLoopData = $order_by_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<td><?php echo e($v_order->users_fullname); ?></td>
									  <td><?php echo e($v_order->users_numbers); ?></td> 
									  <td><?php echo e($v_order->users_email); ?></td>                                     
								</tr>
								                    
							  </tbody>
						 </table>  
						<!--  <div class="pagination pagination-centered">
						  <ul>
							<li><a href="#">Prev</a></li>
							<li class="active">
							  <a href="#">1</a>
							</li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">Next</a></li>
						  </ul>
						</div>      -->
					</div>
				</div><!--/span-->
				<div class="box span6">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>Payment Details</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped">
							  <thead>
								  <tr>
									  <th>Payment Id</th>
									  <th>Method</th>
									  
									                                         
								  </tr>
							  </thead>   
							  <tbody>
								<tr>
									<?php $__currentLoopData = $order_by_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<td><?php echo e($v_order->payment_id); ?></td>
									 <td><?php echo e($v_order->payment_method); ?></td>                              
								</tr>
								                 
							  </tbody>
						 </table>  
						 <!-- <div class="pagination pagination-centered">
						  <ul>
							<li><a href="#">Prev</a></li>
							<li class="active">
							  <a href="#">1</a>
							</li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">Next</a></li>
						  </ul>
						</div>    -->  
					</div>
				</div><!--/span-->
			</div><!--/row-->

			<div class="row-fluid sortable">	
				<div class="box span12">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>Order Details</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<table class="table table-bordered table-striped table-condensed">
							  <thead>
								  <tr>
									  <th> Order Id</th>
									  <th>Book Name</th>
									  <th>Book Price</th>
									  <th>Book sales quantity</th> 
									  <th>Book Subtotal</th>                                         
								  </tr>
							  </thead>   
							  <tbody>
							  	<?php $__currentLoopData = $order_by_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($v_order->order_id); ?></td>
									<td><?php echo e($v_order->book_name); ?></td>
									<td><?php echo e($v_order->book_price); ?></td>
									<td><?php echo e($v_order->book_sales_qty); ?></td>
									<td><?php echo e($v_order->book_price*$v_order->book_sales_qty); ?></td>
									                                       
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								                      
							  </tbody>
							  <tfoot>
							  	<tr>
							  		<td colspan="4">Total with vat:</td>
							  		<td><strong>=<?php echo e($v_order->order_subtotal); ?> TK</strong></td>
							  	</tr>
							  </tfoot>
						 </table>  
						 <div class="pagination pagination-centered">
						  <ul>
							<li><a href="#">Prev</a></li>
							<li class="active">
							  <a href="#">1</a>
							</li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">Next</a></li>
						  </ul>
						</div>     
					</div>
				</div><!--/span-->
			</div><!--/row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/admin/view_order.blade.php ENDPATH**/ ?>