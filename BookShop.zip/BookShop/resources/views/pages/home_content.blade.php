@extends('layout')
@section('content')


@section('slider')
    <!-- HOME -->
    <div id="home">
        <!-- container -->
        <div class="container">
            <!-- home wrap -->
            <div class="home-wrap">
                <!-- home slick -->
                <div id="home-slick">
                    <!-- banner -->
                    <!-- <div class="banner banner-1">
                        <img src="{{asset('frontend/./img/.jpg')}}" alt="">
                        <div class="banner-caption text-center">
                            <h1>Books sale</h1>
                            <h3 class="white-color font-weak">Up to 50% Discount</h3>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div> -->
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{asset('frontend./img/ban2.jpg')}}" alt="">
                        <div class="banner-caption">
                            <h1 class="primary-color">HOT DEAL<br><span class="white-color font-weak">Up to 50% OFF</span></h1>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{asset('frontend/./img/ban4.jpg')}}" alt="">
                        <div class="banner-caption">
                            <h1 class="white-color">Recycle Books <span>Collection</span></h1>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->
                </div>
                <!-- /home slick -->
            </div>
            <!-- /home wrap -->
        </div>
        <!-- /container -->
    </div>
    <!-- /HOME -->
@endsection
@section('category')
    <ul class="category-list">

        <?php
        $all_published_category=DB::table('tbl_category')
            ->get();
        foreach ($all_published_category as $v_category){?>

        <li class="dropdown side-dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">{{ $v_category->category_name}}<i class="fa fa-angle-right"></i></a>
            <!-- <div class="custom-menu">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-links">
                            <li>
                                <h3 class="list-links-title">ইংলিশ মিডিয়াম </h3></li>
                            <li><a href="#">ইংলিশ মিডিয়াম: কেজি</a></li>
                            <li><a href="#">ইংলিশ মিডিয়াম: A লেভেল</a></li>
                            <li><a href="#">ইংলিশ মিডিয়াম: O লেভেল</a></li>
                            <li><a href="#">ইংলিশ মিডিয়াম: ক্লাস ফাইভ</a></li>
                            <li><a href="#">ইংলিশ মিডিয়াম: ক্লাস ফোর</a></li>
                            <li><a href="#">ইংলিশ মিডিয়াম: ক্লাস সিক্স</a></li>

                        </ul>
                        <hr>


                        <ul class="list-links">
                            <li>
                                <h3 class="list-links-title">স্কুল</h3></li>
                            <li><a href="#">নবম ও দশম: বিজ্ঞান</a></li>
                            <li><a href="#">নবম ও দশম: ব্যবসায়</a></li>
                            <li><a href="#">নবম ও দশম: মানবিক</a></li>
                            <li><a href="#">অষ্টম শ্রেণি</a></li>
                            <li><a href="#">পিএসসি</a></li>
                            <li><a href="#">সপ্তম শ্রেণি</a></li>
                        </ul>
                        <hr class="hidden-md hidden-lg">
                    </div>
                    <div class="col-md-6">
                        <ul class="list-links">
                            <li>
                                <h3 class="list-links-title">কলেজ (এইচএসসি)</h3></li>
                            <li><a href="#">উচ্চ মাধ্যমিক বাংলা</a></li>
                            <li><a href="#">উচ্চ মাধ্যমিক ইংরেজি</a></li>
                            <li><a href="#">উচ্চ মাধ্যমিক গণিত</a></li>
                            <li><a href="#">উচ্চ মাধ্যমিক পদার্থবিজ্ঞান</a></li>
                            <li><a href="#">উচ্চ মাধ্যমিক জীববিজ্ঞান</a></li>
                            <li><a href="#">উচ্চ মাধ্যমিক রসায়ন</a></li>
                            <li><a href="#">উচ্চ মাধ্যমিক তথ্য ও যোগাযোগ প্রযুক্তি</a></li>

                        </ul>
                        <hr>
                        <ul class="list-links">
                            <li>
                                <h3 class="list-links-title">কারিগরি শিক্ষা</h3></li>
                            <li><a href="#">অটোমোবাইল ইঞ্জিনিয়ারিং</a></li>
                            <li><a href="#">আর্কিটেকচার</a></li>
                            <li><a href="#">ইলেকট্রিক্যাল এন্ড ইলেকট্রনিক্স ইঞ্জিনিয়ারিং</a></li>
                            <li><a href="#">এনভায়রমেন্টাল ইঞ্জিনিয়ারিং</a></li>
                            <li><a href="#">কম্পিউটার সায়েন্স অ্যান্ড টেকনোলজি</a></li>
                            <li><a href="#">সিভিল ইঞ্জিনিয়ারিং</a></li>

                            <hr class="hidden-md hidden-lg">
                    </div> -->
        <?php } ?>
    </ul>
@endsection
    <!-- section -->
    <div class="section">

        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <!-- section title -->
                <div class="col-md-12">

                    <div class="section-title">
                        <h4 class="title">CSE Engeneering Books</h4>
                        <a href="{{URL::to('/views')}}"><input type="button" value="View All" style="float: right;"> </a>

                    </div>
                            
                  </div>
                

                 <?php  foreach ($all_book_info as $v_book) {?> 
                <!-- section title -->
               
                <!-- Product Single -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="product product-single">
                        <div class="product-thumb">
                           <li><a href="{{URL::to('/view_book/'.$v_book->book_id)}}" button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Quick view</button></a></li>
                            <img src="{{URL::to($v_book->book_image)}}" alt="">
                        </div>
                        <div class="product-body">
                            <h3 class="product-price">TK- {{$v_book->book_price}}</h3>
                           
                           <h2 class="product-name"><a>{{$v_book->book_name}}</a></h2>
                            <h2 class="product-name"><a href="#">{{$v_book->author_name}}</a></h2>
                            <div class="product-btns">
                                <button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
                                <button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
                                <a href="{{URL::to('/view_book/'.$v_book->book_id)}}" button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button></a>
                            </div>

                            
                        </div>
                <!-- /Product Single -->
                  
               
                <!-- /Product Single -->
            </div>
            <!-- /row -->
        </div>
 <?php } ?>
       

                 <div class="row">
                <!-- section title -->
                <div class="col-md-12">
                    
                    <div class="section-title">
                        <h4 class="title">Civil Engeneering Books</h4>
                         <input type="button" value="View All" style="float: right;">
                         
                    </div>
                </div>

                 <?php  foreach ($all_book_info as $v_book) {?> 
                <!-- section title -->

                <!-- Product Single -->
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="product product-single">
                        <div class="product-thumb">
                            <a href="{{URL::to('/view_book/'.$v_book->book_id)}}" button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Quick view</button></a>
                            <img src="{{URL::to($v_book->book_image)}}" alt="">
                        </div>
                        <div class="product-body">
                            <h3 class="product-price">TK.{{$v_book->book_price}}</h3>
                            
                            <h2 class="product-name"><a href="#">{{$v_book->book_name}}</a></h2>
                            <h2 class="product-name"><a href="#">{{$v_book->author_name}}</a></h2>
                            <div class="product-btns">
                                <button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
                                <button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
                                <a href="{{URL::to('/view_book/'.$v_book->book_id)}} "button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button></a>
                            </div>
                        </div>
                    </div>
                </div>
                 <?php } ?>
    </div>
<!-- /section -->

  <div class="row">
                <!-- section title -->
        <div class="col-md-12">
                    
            <div class="section-title">
                <h3 style="color:#D67B22;"> POPULAR AUTHORS </h3>
                  
            </div>
        </div>
           
           <div class="container-fluid" id="author">
      
      <div class="row">
          <div class="col-sm-5 col-md-3 col-lg-3">
          
              <a href="Author.php?value=Durjoy%20Datta"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/00.jpg')}}"></a>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
              <a href="Author.php?value=Chetan%20Bhagat"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/000.jpg')}}"></a>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
              <a href="Author.php?value=Dan%20Brown"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/0.jpg')}}"></a>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
              <a href="Author.php?value=Ravinder%20Singh"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/0000.jpg')}}"></a>
          </div>
      </div>
      <div class="row">
          <div class="col-sm-5 col-md-3 col-lg-3">
              <a href="Author.php?value=Jeffrey%20Archer"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/001.jpg')}}"></a>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
              <a href="Author.php?value=Salman%20Rushdie"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/002.jpg')}}"><a>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
              <a href="Author.php?value=J%20K%20Rowling"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/003.jpg')}}"></a>
          </div>
          <div class="col-sm-6 col-md-3 col-lg-3">
              <a href="Author.php?value=Subrata%20Roy"><img class="img-responsive center-block" src="{{URL::to('frontend/./img/004.jpg')}}"></a>
          </div>
      </div>
  </div>
 </div><br><br>
<!-- /section -->



    
@endsection