@extends('layout')
@section('content')

<div id="wrapper">
         <div id="login" class="animate form">
            <div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span>Add Books</h2>
						
					</div>
					<p class="alert-success">
							<?php
							$messege=Session::get('messege');
							if ($messege) {
								echo $messege;
								Session::put('messege',null);
							}
							?>
							</p>
					<div class="box-content">
						<form class="form-horizontal" action="{{route('user.post.book')}}" method="post" enctype="multipart/form-data">
								{{ csrf_field()}}
						  <fieldset>
							
							<div class="control-group">
							  <label class="control-label" for="date01">Book Name</label>
							  <div class="controls">
								<input type="text" class="input-xlarge " name="book_name" >
							  </div>
							</div>
							<div class="control-group">
								<label class="control-label" for="selectError3">Book Category</label>
								<div class="controls">
								  <select id="selectError3" name="category_id">
								  	<option >Select Category</option>
								  	 <?php 
                                  $all_published_category=DB::table('tbl_category')
                                                        ->get();
                                  foreach ($all_published_category as $v_category){?> 
									<option value="{{$v_category->category_id}}">{{$v_category->category_name}}</option>
									<?php } ?>
								  </select>
								</div>
							  </div>

							  <div class="control-group">
								<label class="control-label" for="selectError3">SubCategory Name</label>
								<div class="controls">
								  <select id="selectError3" name="subcategory_id">
								  	<option >Select SubCategory</option>
								  	 <?php 
                                  $all_published_subcategory=DB::table('tbl_subcategory')
                                                        ->get();
                                  foreach ($all_published_subcategory as $v_subcategory){?> 
									<option value="{{$v_subcategory->subcategory_id}}">{{$v_subcategory->subcategory_name}}</option>
									<?php } ?>
								  </select>
								</div>
							  </div>
							 
							  <div class="control-group">
							  <label class="control-label" for="date01">Author Name</label>
							  <div class="controls">
								<input type="text" class="input-xlarge " name="author_name" >
							  </div>
							</div>


							      
							<div class="control-group hidden-phone">
							  <label class="control-label" for="textarea2">Book description</label>
							  <div class="controls">
								<textarea class="cleditor" name="book_description" rows="3"></textarea>
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="date01">Book price</label>
							  <div class="controls">
								<input type="text" class="input-xlarge " name="book_price" >
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="fileInput">Book Image</label>
							  <div class="controls">
								<input class="input-file uniform_on" name="book_image" id="fileInput" type="file">
							  </div>
							</div>  
							<div class="control-group">
							  <label class="control-label" for="date01">Book Quantity</label>
							  <div class="controls">
								<input type="text" class="input-xlarge " name="book_quantity" >
							  </div>
							</div><br>

							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Add Book</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						</form>   

					</div>
				</div><!--/span-->

			</div><!--/row-->            

        </div>
      </div><br><br><br><br><br><br>
<br><br><br><br><br><br><br>

@endsection()