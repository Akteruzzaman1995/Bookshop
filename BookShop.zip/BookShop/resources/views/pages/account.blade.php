@extends('layout')
@section('content')

@php 

$user = session()->get('user');
@endphp
    

   <div class="container">
        @if(Session::has('message'))
            <div class="alert alert-success text-center" role="alert">
                {{Session::get('message')}}
            </div>
        @endif
        <div class="row">
            <p class="alert-success">
                            <?php
                            $messege=Session::get('messege');
                            if ($messege) {
                                echo $messege;
                                Session::put('messege',null);
                            }
                            ?>
                            </p>
            <div class="col-sm-4 col-sm-offset-1"><br><br>
                <div class="login-form"><!--login form-->
                    <form action="{{route('update.account')}}" method="post" class="form-horizontal">
                        <input type="hidden" name="user_id" value="{{!empty($user->users_id)?$user->users_id:''}}">
                        {{ csrf_field() }}
                         
                        <a href="{{URL::to('/post')}}"><input type="button" value=" SELL BOOKS" class="btn btn-primary" style="float: right;"> </a>
                        <legend>USERS INFORMATION</legend>
                        <div class="form-group {{$errors->has('name')?'has-error':''}}">USERS FULL NAME
                            <input type="text" class="form-control" name="users_fullname" id="name" value="{{!empty($user->users_fullname)?$user->users_fullname:''}}" placeholder="Name"> 
                            <span class="text-danger">{{$errors->first('fullname')}}</span>
                        </div>
                        <div class="form-group {{$errors->has('users_name')?'has-error':''}}">USERS NAME
                            <input type="text" class="form-control" name="users_name" id="users_name" value="{{!empty($user->users_name)?$user->users_name:''}}" placeholder="User Name">
                            <span class="text-danger">{{$errors->first('users_name')}}</span>
                        </div>
                        <div class="form-group {{$errors->has('users_numbers')?'has-error':''}}">USERS NUMBER
                            <input type="text" class="form-control" name="users_numbers" id="users_numbers" value="{{!empty($user->users_numbers)?$user->users_numbers:''}}" placeholder="User number">
                            <span class="text-danger">{{$errors->first('users_numbers')}}</span>
                        </div>
                        <div class="form-group {{$errors->has('users_email')?'has-error':''}}">USERS E-MAIL
                            <input type="text" class="form-control" name="users_email" id="users_email" value="{{!empty($user->users_email)?$user->users_email:''}}" placeholder="User 
                            ">
                            <span class="text-danger">{{$errors->first('users_email')}}</span>
                        </div>
                        <button type="submit" class="btn btn-primary" style="float: right;">UPDATE PROFILE</button>
                    </form>
                </div><!--/login form-->
            </div>
                       

            
            </div>
        </div>
    </div>
    <div style="margin-bottom: 20px;"></div>

</body>
</html>
@endsection