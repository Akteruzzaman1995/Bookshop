@extends('layout')
@section('content')

<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<form action="{{url('/save-shipping')}}" method="post">
					<div class="col-md-8">
						<div class="billing-details">
							<h3>Fillup your information</h3>
							 <!-- <a href="#">Login</a> -->
							 
                            {{ csrf_field() }}

							<div class="section-title">
								<h3 class="title">Shipping Address</h3>
							</div>

							<div class="form-group">
								
								<input class="input" type="text" name="shipping_first_name" required="" placeholder="First Name *">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="shipping_last_name" required="" placeholder="Last Name *">
							</div>
							<div class="form-group">
								<input class="input" type="email" name="shipping_email" required="" placeholder="Email *">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="shipping_address" required="" placeholder="Address *">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="shipping_country" required="" placeholder="Country *">
							</div>
							<div class="form-group">
								<input class="input" type="text" name="shipping_city" required="" placeholder="City *">
							</div>
							
							<!-- <div class="form-group">
								<input class="input" type="text" name="zip-code" placeholder="ZIP Code *">
							</div> -->
							<div class="form-group">
								<input class="input" type="mob" name="shipping_mobile" required="" placeholder="Mobile number *">
							</div>
							<div class="pull-right">
								<a href=""><button class="primary-btn">Continue to payment <i class="fa fa-arrow-circle-right"></i></button></a>
							</div>
							
						</div>
					</div>

				     </div>

					</div>
				</form>

			</div>
			<!-- /row -->
		</div>
		
		<!-- /container -->
	</div>
	<!-- /section -->


@endsection