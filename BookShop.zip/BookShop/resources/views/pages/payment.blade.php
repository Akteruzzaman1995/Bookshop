@extends('layout')
@section('content')


<section id="do_action">
	<div class="container"><br><br>
		
		

                            <ul>
                            	
                           <li><a href="#"><font size="6"><b>Payment Method</b></font></a></li>
                            <font size="4"><span class="payment-header__sub-title">(Please select <em>only one!</em> payment method)</span></font>

                         </ul>


					<form action="{{url('/order-place')}}" method="post">
			         {{csrf_field()}}
                    <input type="radio" name="payment_method" value="handcash"> Hand Cash<br>
                    <input type="radio" name="payment_method" value="cart"> Debit Card<br>

                    <input type="radio" name="payment_method" value="paypal"> Paypal<br><br>
                    <a href=""><button class="primary-btn">Confirm payment </button></a>
			</form>
				</div><br><br><br><br>
	</div>

</section><!--/#do_action-->

@endsection
