@extends('layout')
@section('content')

<div class="container">
	<div class="row">
		<div class="col-md-12">
			@foreach($books as $v_book)
			<div class="col-md-3 col-sm-6 col-xs-6">
	            <div class="product product-single">
	                <div class="product-thumb">
	                   <li><a href="{{URL::to('/view_book/'.$v_book->book_id)}}" button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Quick view</button></a></li>
	                    <img src="{{URL::to($v_book->book_image)}}" alt="">
	                </div>
	                <div class="product-body">
	                    <h3 class="product-price">TK- {{$v_book->book_price}}</h3>
	                   
	                   <h2 class="product-name"><a>{{$v_book->book_name}}</a></h2>
	                    <h2 class="product-name"><a href="#">{{$v_book->author_name}}</a></h2>
	                    <div class="product-btns">
	                        <button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
	                        <button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
	                        <a href="{{URL::to('/view_book/'.$v_book->book_id)}}" button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button></a>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endforeach
		</div>
	</div>
</div>

@endsection