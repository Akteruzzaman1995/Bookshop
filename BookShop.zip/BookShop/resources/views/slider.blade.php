 <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{asset('frontend/./img/ban01.jpg')}}" alt="">
                        <div class="banner-caption text-center">
                            <h1>Books sale</h1>
                            <h3 class="white-color font-weak">Up to 50% Discount</h3>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{asset('frontend./img/ban2.jpg')}}" alt="">
                        <div class="banner-caption">
                            <h1 class="primary-color">HOT DEAL<br><span class="white-color font-weak">Up to 50% OFF</span></h1>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->

                    <!-- banner -->
                    <div class="banner banner-1">
                        <img src="{{asset('frontend/./img/ban4.jpg')}}" alt="">
                        <div class="banner-caption">
                            <h1 class="white-color">New Books <span>Collection</span></h1>
                            <button class="primary-btn">Shop Now</button>
                        </div>
                    </div>
                    <!-- /banner -->