<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//frontent route......................................
Route::get('/', 'HomeController@index');
Route::get('/home-content', 'HomeController@index');

//view............................................ 
Route::get('/view_book/{book_id}','HomeController@book_details_id');
Route::post('/add-to-cart','CartController@add_to_cart');
Route::get('/show-cart','CartController@show_cart');
Route::get('/delete-to-cart/{rowId}','CartController@delete_to_cart');

// Route::get('login','CartController@login');
Route::get('login-check','CheckoutController@login_check');
Route::post('users_registration','CheckoutController@users_registration');
Route::get('checkout','CheckoutController@checkout');
Route::post('save-shipping','CheckoutController@save_shipping');



//Users login----------------------------------------------

Route::post('users_login','CheckoutController@users_login');
Route::get('users_logout','CheckoutController@users_logout');

Route::get('/payment','CheckoutController@payment');
Route::post('/order-place','CheckoutController@order_place');


//User Authentications.....................................

Route::get('/account','CheckoutController@account');
Route::post('/account','CheckoutController@updateAccount')->name('update.account');


//manage-order............................................

Route::get('/manage-order','OrderController@manage_order');
Route::get('/view-order/{order_id}','OrderController@view_order');






//backend route.........................................
Route::get('/admin','AdminController@index');
Route::get('/dashboard','SuperAdminController@index');
Route::post('/admin-dashboard','AdminController@dashboard'); 
Route::get('/logout','SuperAdminController@logout');






//category related.......................................
Route::get('/add-category','CategoryController@index');
Route::get('/all-category','CategoryController@all_category');
Route::post('/save-category','CategoryController@save_category');
Route::post('/update-category/{category_id}','CategoryController@update_category');
Route::get('/unactive_category/{category_id}','CategoryController@unactive_category');
Route::get('/edit-category/{category_id}','CategoryController@edit_category');
Route::get('/delete-category/{category_id}','CategoryController@delete_category');


//Subcategory related.......................................
Route::get('/add-subcategory','SubcategoryController@index');
Route::post('/save-subcategory','SubCategoryController@save_subcategory');
Route::get('/all-subcategory','SubCategoryController@all_subcategory');
Route::get('/edit-subcategory/{subcategory_id}','SubCategoryController@edit_subcategory');
Route::get('/delete-subcategory/{subcategory_id}','SubCategoryController@delete_subcategory');
Route::post('/update-subcategory/{subcategory_id}','SubCategoryController@update_subcategory');


//books are here...........................................

Route::get('/add-book','BookController@index');
Route::post('/save-book','BookController@save_book');
Route::get('/all-book','BookController@all_book');
Route::get('/delete-book/{book_id}','BookController@delete_book');



//Slider............................................

Route::get('/add-slider','SliderController@index');
Route::post('/save-slider','SliderController@save_slider');
Route::get('/all-slider','SliderController@index');

//Bangla Writer
Route::get('bangla/writer','BookController@banglaWriter');



//publication.....................................
Route::get('publication','BookController@publication');

Route::get('views','BookController@views');


//userspost................................
Route::get('post','BookController@post');
Route::post('post/postbook','BookController@postBook')->name('user.post.book');
Route::post('/book/{book}/approve', 'BookController@approve')->name('book.approve');


//search...................................................

Route::post('/search','SearchResultController@search')->name('search');