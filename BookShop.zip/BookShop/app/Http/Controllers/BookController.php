<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;
session_start();

use App\Book;

class BookController extends Controller
{
    public function index()
    {
        $this->AdminAuthCheck();
    	return view('admin.add_book');
    }
     public function all_book()
    {
        $this->AdminAuthCheck();
    	$all_book_info=DB::table('tbl_books')
                         ->join('tbl_category','tbl_books.category_id','=','tbl_category.category_id')
                         ->join('tbl_subcategory','tbl_books.subcategory_id','=','tbl_subcategory.subcategory_id')
                         ->select('tbl_books.*','tbl_category.category_name','tbl_subcategory.subcategory_name')
                         ->get();
        $manage_book=view('admin.all_book')
            ->with('all_book_info',$all_book_info);
         return view('admin_layout')
             ->with('admin.all_book',$manage_book);  
    }

     public function save_book(Request $request)
    {
        $this->AdminAuthCheck();
    	$data=array();
    	$data['book_name']=$request->book_name;
    	$data['category_id']=$request->category_id;
    	$data['subcategory_id']=$request->subcategory_id;
    	$data['author_name']=$request->author_name;
    	$data['book_description']=$request->book_description;
    	$data['book_price']=$request->book_price;
    	
    	$data['book_quantity']=$request->book_quantity;
    	$image=$request->file('book_image');
    if ($image) {
    		$image_name=str_random(20);
    		$ext=strtolower($image->getClientOriginalExtension());
    		$image_full_name=$image_name.'.'.$ext;
    		$upload_path='image/';
    		$image_url=$upload_path.$image_full_name;
    		$success=$image->move($upload_path,$image_full_name);
    		if ($success) {
    			$data['book_image']=$image_url;

    			   DB::table('tbl_books')->insert($data);
    			   Session::put('messege','Book added successfully !!');
    			   return Redirect::to('/add-book');
    		}
           }	
            $data['book_image']='';
                  DB::table('tbl_books')->insert($data);
    			        Session::put('messege','Book added successfully without image !!');
    			        return Redirect::to('/add-book');
    }
    public function delete_book($book_id)
     {
        $this->AdminAuthCheck();
        DB::table('tbl_books')
         ->where('book_id',$book_id)
         ->delete();
        Session::get('messege','Book delete successfully !!'); 
       return Redirect::to('/all-book');
     }
      public function AdminAuthCheck()
    {
        $admin_id=Session::get('admin_id');
        if ($admin_id) {
            return;
        }else{
            return Redirect::to('/admin')->send();
        }
    }


    public function banglaWriter()
    {
        return view('pages.bangla');
    }

    public function publication()
    {
        return view('pages.publication');
    }

    public function views()
    {
        return view('pages.views');
    }

    public function post()
    {
        return view('pages.post');
    }

    public function postBook(Request $request)
    {
        // return $request;
        $data = $this->validate($request, [
            'book_name' =>  'required',
            'category_id'   =>  'required',
            'subcategory_id'    =>  'required',
            'author_name'   =>  'required',
            'book_description'  =>  'required',
            'book_price'    =>  'required',
            'book_quantity' =>  'required',
            'book_image'    =>  'required|image',
        ]);
        

        $media = $request->file('book_image');
        $uploadedMedia = time().'.'.$media->getClientOriginalExtension();
        $destinationPath = public_path('/frontend/img');
        $media->move($destinationPath, $uploadedMedia);
        $data['book_image'] = '/frontend/img/'.$uploadedMedia;
         $book = Book::create($data);
         Session::put('messege','Book added successfully !!');
        return back();
    }

    public function approve($book)
    {
        $data['status'] = 1;
        DB::table('tbl_books')
               ->where('book_id', $book)
               ->update($data);
        return back();
    }
}
