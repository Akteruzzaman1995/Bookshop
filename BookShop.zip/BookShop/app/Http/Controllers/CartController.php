<?php

namespace App\Http\Controllers;


use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Illuminate\Support\Facades\Redirect;
class CartController extends Controller
{
    public function add_to_cart(Request $request)

    {   
    	$quantity=$request->quantity;
    	$book_id=$request->book_id;
    	 $book_info=DB::table('tbl_books')
    	          ->where('book_id',$book_id)
    	          ->first();
            //echo"<pre>" ;
           // print_r($book_info);
            //echo "</pre>";     
          $data['qty']=$quantity;
          $data['id']=$book_info->book_id;
          $data['name']=$book_info->book_name;
          $data['price']=$book_info->book_price;
          $data['options']['image']=$book_info->book_image;

          Cart::add($data);
          return Redirect::to('/show-cart');
   }

       public function show_cart()
       {
         $contents = Cart::content();
         $total = Cart::total();
         $subtotal = Cart::subtotal();
//           $contents=Cart:::getcontent();
//        $all_category=DB::table('tbl_category')
//     	               ->get();
        return view('pages.add_to_cart',compact('contents','total','subtotal'));

//     	   $manage_category=view('pages.add_to_cart')
//              ->with('all_category',$all_category);
//                return view('layout')
//              ->with('pages.add_to_cart',$manage_category);
     }

     public function delete_to_cart($rowId)
     {
      Cart::update($rowId,0);
      return Redirect::to('/show-cart');
     }

     public function login()
     {
         return view('pages.login');
     }
}
