<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;
session_start();

class SubcategoryController extends Controller
{
     public function index()
    {
    	return view('admin.add_subcategory');
    }

    public function save_subcategory(Request $request)
    {
    	$data=array();
    	$data['subcategory_id']=$request->subcategory_id;
    	$data['subcategory_name']=$request->subcategory_name;
    	$data['subcategory_description']=$request->subcategory_description;
    	//$data['publication_status']=$request->publication_status;  
    	DB::table('tbl_subcategory')->insert($data);
    	Session::put('messege','SubCategory added successfully !!');
    	return Redirect::to('/add-subcategory');
    }

    public function all_subcategory()
    {
    	
        $all_subcategory_info=DB::table('tbl_subcategory')->get();
        $manage_subcategory=view('admin.all_subcategory')
            ->with('all_subcategory_info',$all_subcategory_info);
         return view('admin_layout')
             ->with('admin.all_subcategory',$manage_subcategory);  
        //return view('admin.all_category');
    }

     public function edit_subcategory($subcategory_id)
    {
    	$subcategory_info=DB::table('tbl_subcategory')
    	           ->where('subcategory_id',$subcategory_id)
    	           ->first();
    	$subcategory_info=view('admin.edit_subcategory')
    	    ->with('subcategory_info',$subcategory_info);
    	 return view('admin_layout')
    	     ->with('admin.edit_subcategory',$subcategory_info); 
    	
    	//return view('admin.edit_category');
    }

    public function update_subcategory(Request $request,$subcategory_id)
    {
           $data=array();
           $data['subcategory_name']=$request->subcategory_name;
           $data['subcategory_description']=$request->subcategory_description;

           DB::table('tbl_subcategory')
               ->where('subcategory_id',$subcategory_id)
               ->update($data);
               Session::get('messege','SubCategory update successfully !!');
               return Redirect::to('/all-subcategory');
    }

     public function delete_subcategory($subcategory_id)
     {
        DB::table('tbl_subcategory')
         ->where('subcategory_id',$subcategory_id)
         ->delete();
        Session::get('messege','SubCategory delete successfully !!'); 
       return Redirect::to('/all-subcategory');
     }
}
