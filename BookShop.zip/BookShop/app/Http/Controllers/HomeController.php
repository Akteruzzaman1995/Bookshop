<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;


class HomeController extends Controller
{
    public function index()
    {
    	$all_book_info=DB::table('tbl_books')
                         ->join('tbl_category','tbl_books.category_id','=','tbl_category.category_id')
                         ->join('tbl_subcategory','tbl_books.subcategory_id','=','tbl_subcategory.subcategory_id')
                         ->select('tbl_books.*','tbl_category.category_name','tbl_subcategory.subcategory_name')
                         ->where('tbl_books.status', 1)
                         ->limit(4)
                         ->get();
        $manage_book=view('pages.home_content')
            ->with('all_book_info',$all_book_info);
             return view('layout')
            ->with('pages.home_content',$manage_book);  
    	//return view('pages.home_content');
    }

     public function book_details_id($book_id)
    {
        $book_details=DB::table('tbl_books')
                         ->join('tbl_category','tbl_books.category_id','=','tbl_category.category_id')
                         ->join('tbl_subcategory','tbl_books.subcategory_id','=','tbl_subcategory.subcategory_id')
                         ->select('tbl_books.*','tbl_category.category_name','tbl_subcategory.subcategory_name')
                         ->where('tbl_books.book_id',$book_id)
                         ->first();
                         //->get();
        $manage_book_details=view('pages.book_details')
            ->with('book_details',$book_details);
             return view('layout')
            ->with('pages.book_details',$manage_book_details);  
        //return view('pages.home_content');
    }
    
}
