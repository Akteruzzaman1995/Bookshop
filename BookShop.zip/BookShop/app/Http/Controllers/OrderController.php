<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

use App\Http\Requests;
use Session;

class OrderController extends Controller
{
   public function manage_order()
   {
   	$all_order_info=DB::table('tbl_order')
                         ->join('users_table','tbl_order.users_id','=','users_table.users_id')
                         ->select('tbl_order.*','users_table.users_fullname')
                         ->get();
        $manage_order=view('admin.manage_order')
            ->with('all_order_info',$all_order_info);
         return view('admin_layout')
             ->with('admin.manage_order',$manage_order); 
   }

    public function view_order($order_id)
    {
    	 $order_by_id=DB::table('tbl_order')
                         ->join('users_table','tbl_order.users_id','=','users_table.users_id')
                         ->join('tbl_order_details','tbl_order.order_id','=','tbl_order_details.order_id')
                         ->join('tbl_payment','tbl_order.payment_id','=','tbl_payment.payment_id')
                         ->select('tbl_order.*','tbl_order_details.*','tbl_payment.*','users_table.*')
                         
                         ->get();

        $view_order=view('admin.view_order')
            ->with('order_by_id',$order_by_id);
         return view('admin_layout')
             ->with('admin.view_order',$view_order); 

    }
}
