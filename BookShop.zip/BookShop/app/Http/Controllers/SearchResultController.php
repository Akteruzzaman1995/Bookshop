<?php
namespace App\Http\Controllers;

use View;
use App\UserInfo;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Book;

class SearchResultController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    public function search(Request $request)
    {
        $books = Book::where('author_name', 'LIKE', '%'.$request->search.'%')
                        ->orWhere('book_name', 'LIKE', '%'.$request->search.'%')
                        ->get();
        return view('pages.search_result', [
            'books' =>  $books,
        ]);
    }



}
