<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    protected $table = 'tbl_books';

    protected $fillable = [
    	'book_name', 
    	'category_id', 
    	'subcategory_id', 
    	'author_name', 
    	'book_description', 
    	'book_price', 
    	'book_quantity', 
    	'book_image',
    	'status',
    ];
}
